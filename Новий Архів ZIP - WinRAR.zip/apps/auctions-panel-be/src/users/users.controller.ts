import { Body, Controller, Delete, Get, Param, Patch, Post, Query, Req } from '@nestjs/common';
import {
  ApiBody,
  ApiCreatedResponse,
  ApiOkResponse,
  ApiOperation,
  ApiTags,
  getSchemaPath,
} from '@nestjs/swagger';
import { Public } from '../decorators/public.decorator';
import { CreateUserSchema, CreateUserSwaggerDto, type CreateUserDto } from './dto/create-user.dto';
import { SearchUserDto, SearchUserResponseDto } from './dto/search-user.dto';
import { UpdateUserSchema, type UpdateUserDto } from './dto/update-user.dto';
import { UsersService } from './users.service';

@ApiTags('users')
@Controller('users')
export class UsersController {
  constructor(private readonly usersService: UsersService) { }

  @Get('search')
  @ApiOperation({ summary: 'Search users with pagination' })
  @ApiOkResponse({
    description: 'Users found successfully',
    type: SearchUserResponseDto,
  })
  async search(@Query() dto: SearchUserDto, @Req() req): Promise<SearchUserResponseDto> {
    return this.usersService.searchUsers(dto, req.user);
  }

  @Post()
  @Public()
  @ApiBody({ type: CreateUserSwaggerDto })
  @ApiCreatedResponse({
    description: 'User successfully created',
    schema: {
      allOf: [
        {
          type: 'object',
          properties: {
            id: { type: 'string', example: 'Uuid' },
          },
        },
        { $ref: getSchemaPath(CreateUserSwaggerDto) },
      ],
    },
  })
  create(@Body() createUserDto: CreateUserDto, @Req() req) {
    const data = CreateUserSchema.parse(createUserDto);
    if (req.user) {
      return this.usersService.create(data, req.user);
    } else {
      return this.usersService.create(data);
    }
  }

  @Get()
  findAll(
    @Req() req
  ) {
    const user = req.user;
    return this.usersService.findAll(user);
  }

  @Get(':id')
  findOne(@Param('id') id: string) {
    return this.usersService.findOne(id);
  }

  @Patch(':id')
  @ApiBody({ type: CreateUserSwaggerDto })
  @ApiCreatedResponse({
    description: 'User successfully created',
    schema: {
      allOf: [
        {
          type: 'object',
          properties: {
            id: { type: 'string', example: 'Uuid' },
          },
        },
        { $ref: getSchemaPath(CreateUserSwaggerDto) },
      ],
    },
  })
  update(@Param('id') id: string, @Body() updateUserDto: UpdateUserDto) {
    const data = UpdateUserSchema.parse(updateUserDto);
    return this.usersService.update(id, data);
  }

  @Get(':id/control-card')
  @ApiOperation({ summary: 'Отримати картку контролю користувача (ТЗ 15.3)' })
  async getControlCard(@Param('id') id: string, @Req() req) {
    return this.usersService.getUserControlCard(id, req.user);
  }

  @Patch(':id/status')
  @ApiOperation({ summary: 'Зміна статусу/блокування користувача' })
  async updateStatus(@Param('id') id: string, @Body() statusDto: { isBlocked: boolean, isActive: boolean }) {
    return this.usersService.updateUserStatus(id, statusDto);
  }

  @Delete(':id')
  remove(@Param('id') id: string) {
    return this.usersService.remove(id);
  }
}
